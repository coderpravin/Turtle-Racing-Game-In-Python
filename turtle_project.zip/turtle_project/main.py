from turtle import Turtle,Screen
import random
race_on = False
screen = Screen()
screen.title("Turtle Racing Game")
screen.bgcolor('black')
screen.setup(width=500, height=400)
colors = ['red','cyan','green','blue','yellow','purple','pink','brown']
bet = screen.textinput(title="Make your bet buddy", prompt="Which turtle win the race please choose the color(red,cyan,green,blue,yellow,purple,pink,brown) :")
y_axis = [-80,-50,-20,10,40,70,100,130]
all_turtle = []



for i in range(0,8):
    tim = Turtle(shape='turtle')    
    tim.speed(5)
    tim.color(colors[i])
    tim.penup()
    tim.goto(x=-240,y=y_axis[i])
    all_turtle.append(tim)

if bet:
    race_on = True

while race_on:
    for turtle in all_turtle:
        if turtle.xcor()>230:
            race_on = False
            wining_color = turtle.pencolor()
            if wining_color == bet:
                print("Congradulations!!! Your are the winner :", wining_color)
            else:
                print("Your are the loss and winning color is :", wining_color)

            
        rand_distance = random.randint(0,10)
        turtle.forward(rand_distance)



screen.exitonclick()


